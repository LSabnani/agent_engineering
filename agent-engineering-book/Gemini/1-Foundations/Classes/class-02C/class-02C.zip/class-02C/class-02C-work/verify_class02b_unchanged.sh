#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
MANIFEST="$SCRIPT_DIR/class-02B-source.sha256"

if [[ ! -f "$MANIFEST" ]]; then
  echo "Missing checksum manifest: $MANIFEST"
  exit 1
fi

cd "$PACKAGE_ROOT"
sha256sum -c "$MANIFEST"
echo "PASS: the inherited Class 02B source and configuration are unchanged."
