# Class 02C work area

These utilities observe the Class 02B agent without editing its source code.

| File | Purpose |
|---|---|
| `start_api_server.sh` | Starts the unchanged agents with native Google Cloud OpenTelemetry export |
| `run_and_record.sh` | Creates a session, runs two messages, and records session events to JSONL |
| `show_events.sh` | Displays a concise event table |
| `play_events.sh` | Plays the recorded event sequence at a chosen speed |
| `replay_events.py` | Reconstructs the JSONL recording as a new Google Cloud trace |
| `verify_class02b_unchanged.sh` | Verifies the inherited Class 02B source and configuration against the supplied manifest |

Generated files such as `sessions.db`, `events.jsonl`, and `run-*.json` will be written here.
