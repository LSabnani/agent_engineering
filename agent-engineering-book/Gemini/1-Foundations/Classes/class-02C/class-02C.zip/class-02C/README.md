# Class 02C — OpenTelemetry with Google Cloud Trace

This is one self-contained package. It includes the complete Class 02B codebase and the Class 02C telemetry utilities.

## Contents

```text
class-02C/
├── adk_multiagent_systems/       # Complete Class 02B agent code
├── movie_pitches/                # Class 02B output directory
├── scripts/                      # Class 02B validation scripts
├── pyproject.toml                # Original Class 02B project definition
├── .env.api-key.example
├── .env.vertex.example
├── CLASS_02B_INSTRUCTIONS.md     # Original Class 02B lab
├── class_02C_instructions.md     # Class 02C observability lab
└── class-02C-work/               # Telemetry helpers and generated evidence
```

No nested archive is required.

## Start

```bash
unzip class-02C.zip
cd class-02C
less class_02C_instructions.md
```

Create the environment and install the project:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .
python -m pip install "google-adk[otel-gcp]==2.6.0"
```

Use `CLASS_02B_INSTRUCTIONS.md` if the Class 02B agent tasks are not yet complete. Use `class_02C_instructions.md` for recording, showing, playing, and replaying events with Google Cloud Trace.

